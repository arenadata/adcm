#!/usr/bin/env python

import os
import sys
import logging

from command import ROOT_DIR, LOG_DIR, TOP_LOG
from command import get_log_handler, open_file, run_python_script

log = logging.getLogger('status')
log.setLevel(logging.DEBUG)


def read_input(fname):
    f = open(fname, 'r')
    comms = []
    for line in f.read().split('\n'):
        sline = line.strip()
        if sline == '':
            continue
        (service, component, folder, script) = sline.split()
        comms.append((service, component, folder, script))
    f.close()
    return comms


def clear_files():
    try:
        os.unlink('{}/{}-{}.txt'.format(LOG_DIR, 'status', 'out'))
        os.unlink('{}/{}-{}.txt'.format(LOG_DIR, 'status', 'err'))
        os.unlink('{}/{}-{}.txt'.format(LOG_DIR, 'status', 'result'))
    except OSError:
        pass


def run_component_status(folder, script, out_file, err_file):
    base_dir = '{}/cache/{}'.format(ROOT_DIR, folder)
    py_script = '{}/{}'.format(base_dir, script)
    comm = 'STATUS'
    json_config = "{}/data/command-status.json".format(ROOT_DIR)

    res = run_python_script(base_dir, py_script, comm, json_config, out_file, err_file)
    print("status {} res: {}".format(py_script, res))
    return res


def run_status(input_file):
    commands = read_input(input_file)
    clear_files()

    out_file = open_file(LOG_DIR, 'out', 'status')
    err_file = open_file(LOG_DIR, 'err', 'status')
    res_file = open_file(LOG_DIR, 'result', 'status')

    for (service, component, folder, script) in commands:
        res = run_component_status(folder, script, out_file, err_file)
        res_file.write('{} {} {}\n'.format(service, component, res))

    res_file.close()
    out_file.close()
    err_file.close()


def print_usage():
    print('''
    status.py input_file
    ''')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print_usage()
        sys.exit(4)
    else:
        log.addHandler(get_log_handler(TOP_LOG))
        run_status(sys.argv[1])
