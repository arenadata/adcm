
from cm.logger import log
from cm.errors import AdcmEx

from cm.models import Prototype, Action


def task_generator(action, selector):
    log.debug("call task_generator: %s", action)
    try:
        service = Prototype.objects.get(type='service', name='ZOOKEEPER', version='1.2')
    except Prototype.DoesNotExist:
        raise AdcmEx('TASK_GENERATOR_ERROR', 'service ZOOKEEPER not found')

    try:
        stop = Action.objects.get(context='service', context_id=service.id, name='stop')
    except Prototype.DoesNotExist:
        raise AdcmEx('TASK_GENERATOR_ERROR', 'action stop of service ZOOKEEPER not found')

    try:
        start = Action.objects.get(context='service', context_id=service.id, name='start')
    except Prototype.DoesNotExist:
        raise AdcmEx('TASK_GENERATOR_ERROR', 'action start of service ZOOKEEPER not found')

    return (
        {'action': stop, 'selector': selector},
        {'action': start, 'selector': selector},
    )
