#!/usr/bin/env python3

import os
import sys
import json
from jinja2 import Template


def render(template_file_name, context):
    try:
        fd = open(template_file_name)
    except FileNotFoundError:
        print("Can't open template file: '{}'".format(template_file_name))
        sys.exit(2)
    tmpl = Template(fd.read())
    fd.close()
    return tmpl.render(c=context)


def render_to_file(template_file_name, out_file_name, context):
    try:
        fd = open(out_file_name, 'w')
    except FileNotFoundError:
        print("Can't open output file: '{}'".format(out_file_name))
        sys.exit(2)
    fd.write(render(template_file_name, context))
    fd.close()


def read_json(json_file_name):
    try:
        fd = open(json_file_name)
    except FileNotFoundError:
        print("Can't open json config file: '{}'".format(json_file_name))
        sys.exit(2)
    config = json.load(fd)
    fd.close()
    return config


def template(tmpl, out_file, config):
    json_conf = read_json(config)
    render_to_file(tmpl, out_file, json_conf)


def do():
    if len(sys.argv) < 4:
        print("\nUsage:\n{} template out_file config.json\n".format(os.path.basename(sys.argv[0])))
        sys.exit(4)
    else:
        template(sys.argv[1], sys.argv[2], sys.argv[3])


if __name__ == '__main__':
    do()
